import { Component, OnInit } from '@angular/core';
import { DataService } from '../employee.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.css'],
  providers: [DataService]
})
export class EmployeesComponent implements OnInit {

  constructor( private service: DataService, private router:Router ) { }
  
  data: any[];
  ngOnInit() {
  this.service.getData().subscribe(d => this.data= d)
  }
  getDataById(id){
  this.router.navigate(["/employee", id]);
  }

}
