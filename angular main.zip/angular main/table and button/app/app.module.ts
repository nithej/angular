import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router'

import { AppComponent } from './app.component';
import { EmployeeComponent } from './employee/employee.component';
import { SampleComponent } from './sample/sample.component';
import { SalarypipePipe } from './salary.pipe';
import { PnfComponent } from './pnf/pnf.component';

const routes: Routes = [

    {path: 'employee', component: EmployeeComponent},
    {path: 'sample', component: SampleComponent},
    {path: '', component: EmployeeComponent},
    {path: '**', component: EmployeeComponent},


]


@NgModule({
  declarations: [
    AppComponent,
    EmployeeComponent,
    SampleComponent,
    SalarypipePipe,
    PnfComponent
  ],
  imports: [
    BrowserModule, FormsModule, RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
