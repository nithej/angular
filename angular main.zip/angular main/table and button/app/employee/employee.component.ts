import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  classtouse:string = 'class2';
  useclass3:boolean=false;
  data:boolean=false;
  firstname:string = 'Nithej';
  lastname:string = 'Konda';
  salary:number =  10000;
  fullName():string{
  return this.firstname+' '+this.lastname;
  }
  buttonClick():void{
  this.data =! this.data;
  }
  empnames:string[]=["Emp1","Emp2","Emp3"];
  
  employees: any[] =[
  {id:100,firstName: "Nithej", lastName: "Konda", salary: 10000, department:"EEE", doj: "16/sep/2016"},
  {id:100,firstName: "Nithej", lastName: "Konda", salary: 10000, department:"EEE", doj: "16/oct/2016"}

  ];
  ngOnInit(){}
}
